// 
let pularFormulario = confirm("Quer pular o formulário e usar dados prontos?");

let nome, sobrenome, idade, areaInteresse, favorito;

// if Se for pular formulario
if (pularFormulario) {
    nome = "Flávia";
    sobrenome = "Lorena";
    idade = 20;
    areaInteresse = "Tecnologia em geral(pq ainda nao tenho certeza da area)";
    favorito = "As cronicas de Narnia";
} else {
    // se n, vai pedir info
    nome = prompt("Qual seu nome?");
    sobrenome = prompt("Qual seu sobrenome?");
    idade = parseInt(prompt("Qual sua idade?"));
    areaInteresse = prompt("Qual sua área de interesse?");
    favorito = prompt("Qual seu anime, filme ou série favorito?");
}


let maiorIdade = idade >= 18; //comparador 

//vai aparecer
let mensagem = `Olá, me chamo ${nome} ${sobrenome}!\n`;
mensagem += `Idade: ${idade} anos.\n`;
mensagem += `Área de Interesse: ${areaInteresse}\n`;
mensagem += `Anime/Filme/Série favorito: ${favorito}\n`;

if (maiorIdade) {
    mensagem += "Obá, eu sou maior de idade!";
} else {
    mensagem += "Poxa, eu sou menor de idade!";
}

// Mostra no alerta
alert(mensagem);

// mostra no console
console.log(mensagem);


