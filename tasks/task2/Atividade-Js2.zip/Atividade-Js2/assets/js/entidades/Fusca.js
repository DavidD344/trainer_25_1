import { Carro } from "./Carro.js";

export class Fusca extends Carro{
    constructor(nome, placa, cor, ano, ronco, velocidade){
        super(nome, placa, cor, ano);
        this.ronco = ronco;
        this.velocidade = velocidade;
    }

    roncar(){
        return this.ronco;
    }

    competir(){
        return this.velocidade;
    }
}
    