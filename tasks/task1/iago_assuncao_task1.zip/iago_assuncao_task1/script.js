let nome = "";
let sobrenome = "";
let idade = "";
let areaInteresse = "";
let gostoInteresse = "";
let linguagemFavorita = "";

const pre_definido = () => {
    nome = "Iago";
    sobrenome = "Amorim";
    idade = 23;
    areaInteresse = "Desenvolvedor";
    gostoInteresse = "Filmes Marvel";
    linguagemFavorita = "JavaScript";
};

const mensagem = () => `
    Nome: ${nome} ${sobrenome}
    Idade: ${idade} (${idade >= 18 ? "Maior de idade" : "Menor de idade"})
    Área de Interesse: ${areaInteresse}
    Categoria de Interesse: ${gostoInteresse}
    Linguagem Favorita: ${linguagemFavorita}
`;

const camposVazios = () => {
    let vazios = 0;
    if (nome.length < 3) vazios++;
    if (sobrenome.length < 3) vazios++;
    if (idade.length < 1) vazios++;
    if (areaInteresse.length < 3) vazios++;
    if (gostoInteresse.length < 3) vazios++;
    return vazios;
};

const perguntarLinguagem = () => {
    const opcoes = ["JavaScript", "Python", "Java", "C#"];
    while (true) {
        linguagemFavorita = prompt(
            `Qual sua linguagem favorita? Escolha entre: ${opcoes.join(", ")}`
        );
        if (opcoes.includes(linguagemFavorita)) break;
        alert("Por favor, escolha uma das opções válidas.");
    }
};

const botaoIniciar = document.getElementById("iniciar");

botaoIniciar.addEventListener("click", () => {
    do {
        if (confirm("Quer responder o formulário?")) {
            nome = prompt("Nome:");
            sobrenome = prompt("Sobrenome:");
            idade = prompt("Idade:");
            areaInteresse = prompt("Área de interesse:");
            gostoInteresse = prompt("Anime/Filme/Série:");
            perguntarLinguagem();

            const vazios = camposVazios();
            if (vazios > 0) {
                alert(`Você deixou ${vazios} campo(s) vazio(s).`);
            }

            alert(mensagem());
        } else if (confirm("Quer ver os valores pre-definidos?")) {
            pre_definido();
            alert(mensagem());
        } else {
            alert("Programa encerrado.");
            break;
        }
    } while (confirm("Deseja preencher novamente o formulário?"));
});
