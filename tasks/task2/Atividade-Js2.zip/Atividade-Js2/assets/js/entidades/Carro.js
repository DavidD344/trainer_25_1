export class Carro{
    constructor(nome, placa, cor, ano){
        this.nome = nome;
        this.placa = placa;
        this.cor = cor;
        this.ano = ano;
    }

    getNome(){
        return this.nome;
    }

    getPlaca(){
        return this.placa;
    }

    getCor(){
        return this.cor;
    }

    getAno(){
        return this.ano;
    }


}