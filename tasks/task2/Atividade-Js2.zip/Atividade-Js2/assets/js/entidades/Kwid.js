import { Carro } from "./Carro.js";

export class Kwid extends Carro{
    constructor(nome, cor, placa, ano, ronco, velocidade){
        super(nome, cor , placa, ano);
        this.ronco = ronco;
        this.velocidade = velocidade;
    }

    roncar(){
        return this.ronco;
    }

    competir(){
        return this.velocidade;
    }
}