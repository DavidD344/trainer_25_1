console.log("Você é besta mesmo, né? KKKKKK Que otário, mano. O cara obedece um site KKKKK")
function inicio(){
alert("Bem vindo usuário! Gostariamos de saber mais sobre você. Por favor, seja honesto nas perguntas a seguir.");
confirm("Você é gay?");
alert("É brincadeira! Não precisa responder isso.");

let burlar = confirm("Deseja burlar o sistema e colocar qualquer coisa?");

let nome = "Dimitri";
let sobrenome = "Franco";
let idade = 18;
let areaInt = "Ciência da Computação";
let midia = "Interestelar";
let progFav = "Java";

if(!burlar){
    nome = prompt("Qual é o seu nome?");
    sobrenome = prompt("Qual é o seu sobrenome?");
    idade = prompt("Qual é a sua idade?");
    areaInt = prompt("Qual é a sua área de interesse?");
    midia = prompt("Qual é a sua mídia favorita?");
    
    let progLoop = true;
    while (progLoop){ 
    progFav = prompt("Qual é a sua linguagem de programação favorita? \n- Java \n- C \n- Python \n- JavaScript \n- C++ \n- C#");
    if(progFav != "Java" && progFav != "C" && progFav != "Python" && progFav != "JavaScript" && progFav != "C++" && progFav != "C#"){
        alert("Você não sabe programar, né? Não tem problema, só coloca qualquer uma dessas ai.");
    } else{
        progLoop = false;
    }
    }

    if (nome.length < 3 || sobrenome.length < 3 || idade.length < 1 || areaInt.length < 2 || midia.length < 3) {
        alert("Você tá realmente querendo me enganar? Preencha corretamente, mano. Mas agora vai ficar assim mesmo, problema seu.");;
    }
}

let dMaior;
if(idade < 18) {
    dMaior = "jovem";
} else{
    dMaior = "velho";
}

alert(`Muito bem, ${nome} ${sobrenome}! Por ter ${idade} anos, você é muito ${dMaior} para entrar na organização.`);
alert(`E ${areaInt} com ${progFav}??? Vai ficar pobre mano... Você é um medíocre. E pra piorar ainda gosta de ${midia}...`);
}

inicio();
let loop = true;
while (loop) {
    loop = confirm("Se confundiu em algo, e quer preencher novamente?");
    if (loop) {
        alert("Você é meio burro, mas ok...");
        inicio();
    }
    else {
        alert("Oh glória! Já não aguentava mais...");
        break;
    }
}