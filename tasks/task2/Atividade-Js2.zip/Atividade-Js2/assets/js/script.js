import {Kwid} from "./entidades/Kwid.js";
import {UnoDeEscada} from "./entidades/UnoDeEscada.js";
import {Fusca} from "./entidades/Fusca.js";

alert('Bem-vindo a corrida de carros!')

let vel1 = Math.floor(Math.random() * 20) + 1
let vel2 = Math.floor(Math.random() * 20) + 1   
let vel3 = Math.floor(Math.random() * 20) + 1

const fusquinha = new Fusca("Besourinho", "B350UR0", "Azul Escuro", 1973 , "popopopopopoooooooon", vel1)
const kwidesgraca = new Kwid("Kwidesgraça" , "K1W1D3GR4C4", "Amarelo Neon", 2020 , "vunnnpvunnnptontonton", vel2)
const unoDeEscada = new UnoDeEscada("O Da Firma", "F1RM4", "Branco", 1999 , "tuctucutucvrommmmm", vel3)

alert(fusquinha.roncar())
alert(kwidesgraca.roncar()) 
alert(unoDeEscada.roncar())

if(fusquinha.competir() > kwidesgraca.competir() && fusquinha.competir() > unoDeEscada.competir()){
    alert(`${fusquinha.getNome()} é o campeão! Em apenas ${fusquinha.competir()} ele ganhou a corrida!`)
} else if(kwidesgraca.competir() > fusquinha.competir() && kwidesgraca.competir() > unoDeEscada.competir()){
    alert(`${kwidesgraca.getNome()} é o campeão! Em apenas ${kwidesgraca.competir()} ele ganhou a corrida!`)
} else if(unoDeEscada.competir() > fusquinha.competir() && unoDeEscada.competir() > kwidesgraca.competir()){
    alert(`${unoDeEscada.getNome()} é o campeão! Em apenas ${unoDeEscada.competir()} segundos ele ganhou a corrida!`)
} else{
    alert('Houve um empate entre os carros')
}